# 10 Technical Handoff

**Project:** BIOSTEAM
**Upstream:** https://github.com/biosteam/biosteam

Content specific to BIOSTEAM in category CHEMICAL_PRODUCTION.
